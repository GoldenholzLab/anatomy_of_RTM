"""RTM anatomy simulation utilities."""

